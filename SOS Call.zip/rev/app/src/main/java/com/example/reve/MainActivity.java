package com.example.reve;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;

public class MainActivity extends AppCompatActivity {

    EditText etContact;
    Switch switchCall;
    Button btnSOS;
    Button btnSaveContact;

    FusedLocationProviderClient fusedLocationClient;
    SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "WomenSafetyPrefs";
    private static final String KEY_EMERGENCY_CONTACT = "emergency_contact";
    private static final String KEY_CALL_ENABLED = "call_enabled";

    private static final int PERMISSION_CODE = 101;

    String[] permissions = {
            Manifest.permission.SEND_SMS,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.CALL_PHONE
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etContact = findViewById(R.id.etContact);
        switchCall = findViewById(R.id.switchCall);
        btnSOS = findViewById(R.id.btnSOS);
        btnSaveContact = findViewById(R.id.btnSaveContact);

        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Load saved contact number and call preference
        loadSavedSettings();

        // Save contact button
        btnSaveContact.setOnClickListener(v -> {
            String phone = etContact.getText().toString().trim();
            if (TextUtils.isEmpty(phone)) {
                Toast.makeText(this, "Please enter an emergency contact number!", Toast.LENGTH_SHORT).show();
            } else {
                saveSettings();
                Toast.makeText(this, "Emergency contact saved!", Toast.LENGTH_SHORT).show();
            }
        });

        // SOS button
        btnSOS.setOnClickListener(v -> {
            if (!hasPermissions()) {
                ActivityCompat.requestPermissions(MainActivity.this, permissions, PERMISSION_CODE);
            } else {
                sendSOS();
            }
        });
    }

    private void loadSavedSettings() {
        String savedContact = sharedPreferences.getString(KEY_EMERGENCY_CONTACT, "");
        boolean callEnabled = sharedPreferences.getBoolean(KEY_CALL_ENABLED, false);
        
        if (!savedContact.isEmpty()) {
            etContact.setText(savedContact);
        }
        switchCall.setChecked(callEnabled);
    }

    private void saveSettings() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_EMERGENCY_CONTACT, etContact.getText().toString().trim());
        editor.putBoolean(KEY_CALL_ENABLED, switchCall.isChecked());
        editor.apply();
    }

    private boolean hasPermissions() {
        for (String p : permissions) {
            if (ActivityCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    private void sendSOS() {
        // First try to get saved contact, if not use the one from EditText
        String phoneNumber = sharedPreferences.getString(KEY_EMERGENCY_CONTACT, "");
        if (phoneNumber.isEmpty()) {
            phoneNumber = etContact.getText().toString().trim();
        }

        if (TextUtils.isEmpty(phoneNumber)) {
            Toast.makeText(this, "Please enter and save an emergency contact number!", Toast.LENGTH_SHORT).show();
            return;
        }

        final String phone = phoneNumber; // Make final for lambda usage

        // Get location if permission is granted
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) 
                == PackageManager.PERMISSION_GRANTED) {
            // Try to get current location first
            fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
                    .addOnSuccessListener(location -> {
                        if (location != null) {
                            double lat = location.getLatitude();
                            double lon = location.getLongitude();
                            String mapsLink = "https://maps.google.com/?q=" + lat + "," + lon;
                            String message = "🚨 SOS ALERT! I need immediate help!\n\nMy current location:\n" + mapsLink + 
                                    "\n\nLatitude: " + lat + "\nLongitude: " + lon;
                            sendSMSAndCall(phone, message);
                        } else {
                            // Fallback to last known location
                            getLastLocationAndSend(phone);
                        }
                    })
                    .addOnFailureListener(e -> {
                        // If getCurrentLocation fails, try getLastLocation
                        getLastLocationAndSend(phone);
                    });
        } else {
            // If location permission not granted, send SMS without location
            String message = "🚨 SOS ALERT! I need immediate help!\n\nLocation permission not granted.";
            sendSMSAndCall(phone, message);
        }
    }

    private void getLastLocationAndSend(final String phone) {
        fusedLocationClient.getLastLocation().addOnSuccessListener(lastLocation -> {
            String message;
            if (lastLocation != null) {
                double lat = lastLocation.getLatitude();
                double lon = lastLocation.getLongitude();
                String mapsLink = "https://maps.google.com/?q=" + lat + "," + lon;
                message = "🚨 SOS ALERT! I need immediate help!\n\nMy last known location:\n" + mapsLink + 
                        "\n\nLatitude: " + lat + "\nLongitude: " + lon;
            } else {
                message = "🚨 SOS ALERT! I need immediate help!\n\nLocation unavailable at the moment.";
            }
            sendSMSAndCall(phone, message);
        }).addOnFailureListener(e -> {
            // If location fails, send SMS without location
            String message = "🚨 SOS ALERT! I need immediate help!\n\nLocation unavailable.";
            sendSMSAndCall(phone, message);
        });
    }

    private void sendSMSAndCall(String phone, String message) {
        sendSMS(phone, message);
        if (switchCall.isChecked()) {
            makeCall(phone);
        }
    }

    private void sendSMS(String phone, String msg) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phone, null, msg, null, null);
            Toast.makeText(this, "SOS SMS Sent!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void makeCall(String phone) {
        try {
            Intent intent = new Intent(Intent.ACTION_CALL);
            intent.setData(Uri.parse("tel:" + phone));

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
                    == PackageManager.PERMISSION_GRANTED) {
                startActivity(intent);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Call Failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_CODE) {
            if (hasPermissions()) {
                Toast.makeText(this, "Permissions Granted! Press SOS again.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permissions required to use SOS.", Toast.LENGTH_LONG).show();
            }
        }
    }
}
